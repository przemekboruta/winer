"""NLPSubtask implementation."""
import logging
import re

from ._subtaskbase import SubTaskBase, _timeout_manager

_log = logging.getLogger(__name__)


class SubTask(SubTaskBase):
    """Class implementing SubTask."""

    def __init__(self, input_path: str, task: dict, prefix="/samba") -> None:
        """Constructor.

        :param input_path: input pat
        :type input_path: str
        :param task: task to do
        :type task: dict
        :param prefix: prefix, defaults to "/samba"
        :type prefix: str, optional
        :raises Exception: when SubTask is off
        """
        if not SubTask._on:
            raise Exception(
                "Turn on SubTask features first, by SubTask.turn_on()")
        super().__init__()
        self.task = task
        self.input = self._transform_path(input_path, prefix)
        self.response = None

    def _transform_path(self, path: str, prefix: str) -> str:
        """Cuts off path prefix.

        :param path: path with or without prefix
        :type path: str
        :param prefix: prefix to be removed
        :type prefix: str
        :return: path without prefix
        :rtype: str
        """
        match = re.search(r"^" + str(prefix) + r"(.*)", path)
        if match:
            return match.group(1)
        else:
            return path

    def run(self, blocking=True, timeout=0, verbose=False) -> None:
        """Run task.

        :param blocking: If the call of this function should be blocking,
            defaults to True.
        :type blocking: bool, optional

        :param timeout: Timeout used if blocking=True.
            Pass '0' if the function should wait until the task is
            finished or error occurred (raise an exception), defaults to 0.
        :type timeout: float, optional

        :param verbose: Print progress or not, defaults to False.
        :type verbose: bool, optional
        """
        self.get_new_idx()
        data = {
            "pid": self.process_id,
            "task": self.task,
            "input": self.input,
            "id": self.idx
        }
        _log.debug(f"Running subtask {data}")
        self.q_out.put(data)

        if blocking:
            with _timeout_manager(timeout, str(self.task)):
                self.wait(verbose=verbose)

    def get_progress(self) -> float:
        """Returns progress of the running task.

        :return: A progress (value between 0 and 1).
        :rtype: float
        """
        finished = not self.q_in.empty()

        if finished:
            self.response = self.q_in.get()
            del SubTask._subtasks_queus[self.idx]
            return 1
        else:
            return 0

    def get_output_path(self, timeout=0) -> str:
        """Returns path to the output (result of completed task).

        The function waits if its needed.

        :param timeout: timeout, defaults to 0
        :type timeout: int, optional
        :return: output path
        :rtype: str
        """
        if not self.response:
            with _timeout_manager(timeout, str(self.task)):
                self.wait()
        return str(self._get_output_file())

    def _get_output_file(self):
        """Returns output file.

        :raises Exception: when status is not equal to done
        :return: path to file
        :rtype: path
        """
        result = self.response
        error_msg = ""
        if "error" in result:
            error_msg = result["error"]
        if result["status"] != "DONE":
            raise Exception("subtask error: " + error_msg)
        else:
            return result["value"]
