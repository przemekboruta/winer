"""Logserver implementation."""
from __future__ import absolute_import, division, unicode_literals

import logging
import time
from logging.handlers import RotatingFileHandler
from struct import Struct
from threading import Thread

from six.moves import cPickle, socketserver

__all__ = ['LogServer', 'configure_loggers', 'parse_loglevel']
_DEFAULT_LOGFORMAT = (
    '%(asctime)s [%(levelname)s]: %(processName)s %(message)s')
# Since logging module doesn't standardize name-to-level conversion, here's a
# dict with the standard levels.
_NAME2LVL = {
    'CRITICAL': 50,
    'ERROR': 40,
    'WARNING': 30,
    'INFO': 20,
    'DEBUG': 10,
}

_logger = logging.getLogger(__name__)
# Main logger is configured for loggers in this library themselves. It gets the
# same handler as worker loggers.
_main_logger = logging.getLogger(__name__.split('.', 1)[0])
# The logger that handles logs the remote loggers. It remains aside loggers for
# this library, accepts everything, logs nothing on its own and only handles
# received log records.
_service_logger = logging.getLogger('<service-remote>')

_handler = None


def configure_loggers(logfile_name='service.log',
                      logfile_maxsize=1024**2,
                      logfile_maxbackups=10,
                      log_format=_DEFAULT_LOGFORMAT,
                      local_log_level='INFO'):
    """Configure the logger used by :class`LogServer` instances.

    This function must be called before any logging servers are started (not
    that there should ever be need for more than one) and cannot be called
    again. This is to ensure thread safety.

    :param logfile_name: Name of the file to which logs are written,
        defaults to 'service.log'.
    :type logfile_name: str, optional

    :param logfile_maxsize: Maximal size in bytes of a single rotating
        log file, defaults to 1 MiB.
    :type logfile_maxsize: int, optional

    :param logfile_maxbackups: Maximal number of backup log files kept,
        defaults to 10.
    :type logfile_maxbackups: int, optional

    :param log_format: Format string for log records output by this
        server. A reasonable default is provided.
    :type log_format: str, optional

    :param local_log_level: Name of the log level for loggers in *this*
        library. Refer to standard documentation for possible names. This
        setting does not affect loggers from workers, defaults to 'INFO'.
    :type local_log_level: str, optional
    :raises RuntimeError: when logger already configured.
    """
    global _handler

    if _handler is not None:
        raise RuntimeError('Cannot configure logger twice')

    _handler = RotatingFileHandler(logfile_name,
                                   maxBytes=logfile_maxsize,
                                   backupCount=logfile_maxbackups,
                                   encoding='utf-8',
                                   delay=True)
    fmter = logging.Formatter(log_format)
    _handler.setFormatter(fmter)

    _main_logger.addHandler(_handler)
    _main_logger.setLevel(parse_loglevel(local_log_level))

    _service_logger.addHandler(_handler)
    # Make sure this will accept everything. Worker loggers should do
    # filtering.
    _service_logger.setLevel(logging.NOTSET)

    # Also log to stderr (usually will be screen). This does not require any
    # fussing.
    stdhandler = logging.StreamHandler()
    stdhandler.setFormatter(fmter)
    _main_logger.addHandler(stdhandler)
    _service_logger.addHandler(stdhandler)


def parse_loglevel(log_level):
    """Get logging level constant number from a string.

    If the string is an integer literal, return it as integer. Otherwise try to
    interpret the string as one of the standard level names and return value
    associated with that.

    :param log_level: String naming the log level, to be parsed.
    :type log_level: str

    :return: Integer value of the log level, as used by ``logging`` module.
    :rtype: int

    :raise KeyError: When ``log_level`` is neither an integer literal nor
        the name of a standard logging level.
    """
    try:
        lvlnum = int(log_level)
    except ValueError:
        lvlnum = _NAME2LVL[log_level.upper()]

    return lvlnum


class LogServer(object):
    """Creates and starts a logging server thread.

    This threads awaits for ``LogRecord`` pickles from a given port
    on localhost and logs them to a rotating file handler.

    The thread is meant to run while waiting for subprocesses to end, so it
    should not impact efficiency. The thread will also spend most of its time
    listening on socket.

    The logging server can be told to shutdown at any time.
    """

    HOST = str('localhost')
    SHUTDOWN_POLL_INTERVAL = 2.

    def __init__(self, port):
        """Initialize LogServer.

        :param port: Number of TCP port the server will be listening on.
        :type port: int
        """
        self._port = port
        self._sserver = _LogSocketServer((self.HOST, port), _LogRequestHandler)
        self._sthread = Thread(target=self._sserver.serve_forever,
                               args=(self.SHUTDOWN_POLL_INTERVAL,),
                               name='logging')

    @property
    def socket_address(self):
        """The address tuple for socket handlers to connect to this server.

        :return: socker_address
        :rtype: tuple[str, int]
        """
        return self.HOST, self._port

    def start(self):
        """Start the logging thread and return immediately.

        :raises RuntimeError: If :func:`configure_loggers` has not been
            called before this method.
        """
        if _handler is None:
            raise RuntimeError('configure_loggers() has not been '
                               'called before starting')

        self._sthread.start()

    def shutdown(self):
        """Shutdown the logging server and thread.

        If the thread is not alive, silently do nothing.
        """
        if not self._sthread.is_alive():
            return

        self._sserver.shutdown()
        self._sthread.join()


class _LogSocketServer(socketserver.TCPServer):
    # By default, socket errors go to stdout. We want them integrated
    # nicely with the logging system, hence this subclass.
    # This handler is called from except block in socketserver code, so
    # it's safe to log exceptions.

    def handle_error(self, request, client_address):
        _logger.exception('Error while handling message from %r',
                          client_address)


class _LogRequestHandler(socketserver.StreamRequestHandler):
    # This handler is based on the stdlib example:
    # https://docs.python.org/2/howto/logging-cookbook.html#sending-and-receiving-logging-events-across-a-network
    # But it uses a UNIX stream socket.

    # According to the example, the log record length prefix is an unsigned
    # long. Calculate its size more flexibly then the hard-coded 4 bytes in the
    # example.
    # str cast is for python2 compatibility.
    __PREFIX_STRUCT = Struct(str('!L'))

    def handle(self):
        for chunk in self.__iter_log_prefixes():
            # Get the integer representing length.
            loglen = self.__PREFIX_STRUCT.unpack(chunk)[0]
            chunk = self.__read_log_record(loglen)

            if chunk:
                logdict = cPickle.loads(chunk)
                logrecord = logging.makeLogRecord(logdict)
                _service_logger.handle(logrecord)

    def __iter_log_prefixes(self):
        chunk = self.__read_log_prefix()

        while len(chunk) == self.__PREFIX_STRUCT.size:
            yield chunk
            chunk = self.__read_log_prefix()

        if len(chunk) > 0:
            _logger.warning('Trailing bytes after log record(s): %s', chunk)

    def __read_log_prefix(self):
        return self.rfile.read(self.__PREFIX_STRUCT.size)

    def __read_log_record(self, loglen):
        chunk = self.rfile.read(loglen)

        while len(chunk) < loglen:
            time.sleep(1)
            newchunk = self.rfile.read(loglen - len(chunk))

            if len(newchunk) == 0:
                _logger.error(
                    'Cannot get full log record: expcted %d bytes, '
                    'only got %d',
                    loglen,
                    len(chunk),
                )
                return b''

            chunk += newchunk

        return chunk
