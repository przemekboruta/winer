"""NLPSubtask implementation."""
import _thread
import logging
import os
import queue
import threading
import time
import uuid
from contextlib import contextmanager

from tqdm import tqdm

_log = logging.getLogger(__name__)


@contextmanager
def _timeout_manager(time: float, msg=''):
    """Manage timeouts.

    :param time: timeout duraction
    :type time: float
    :param msg: task name, defaults to ''
    :type msg: str, optional
    :raises TimeoutError: on KeyboardInterrupt
    """
    timer = threading.Timer(time, lambda: _thread.interrupt_main())
    if time > 0:
        timer.start()
    try:
        yield
    except KeyboardInterrupt:
        raise TimeoutError("Operation " + str(msg) + " timeout.")
    finally:
        timer.cancel()


class SubTaskBase(object):
    """Class implementing SubTaskBase."""

    _queue_to_service = None
    _processes = {}
    _subtasks_queus = {}
    _on = False

    @staticmethod
    def turn_on():
        """Turns on SubTaskBase."""
        SubTaskBase._on = True

    @staticmethod
    def prepare_subtask(parameters: dict, process_id: int) -> None:
        """Prepares subtask parameters.

        :param parameters: parameters
        :type parameters: dict
        :param process_id: process id
        :type process_id: int
        """
        SubTaskBase._processes[process_id] = parameters
        if SubTaskBase._on:
            thread = threading.Thread(target=SubTaskBase.proxy_from_service)
            thread.start()

    @staticmethod
    def proxy_from_service() -> None:
        """Proxy from service.

        id of response contains of idx (index in _subtasks_queus ) and
        sub_id (local id if many tasks are run) joined with # i.e. idx#sub_id
        sub_id is used in Sentence class
        """
        process_id = os.getpid()
        while True:
            response = SubTaskBase._processes[process_id]["q_in"].get()
            if "id" not in response:
                _log.error("Subtask/sentence response without id {}".format(
                    str(response)[:100]))
                continue
            _resp = {i: response[i] for i in response if i != 'value'}
            if "value" in response:
                _resp["value"] = f"List of len. {str(len(response['value']))}"
            _log.debug(f"Subtask/sentence response {_resp}")
            els = response["id"].split("#")
            idx = els[0]
            sub_id = els[1] if len(els) > 1 else "0"
            response["sub_id"] = sub_id
            if idx in SubTaskBase._subtasks_queus:
                SubTaskBase._subtasks_queus[idx].put(response)
            else:
                _log.error(f"No queue for task {idx} with id {response['id']}")

    def get_new_idx(self):
        """Gets new idx."""
        if self.idx is not None and self.idx in SubTaskBase._subtasks_queus:
            del SubTaskBase._subtasks_queus[self.idx]
        self.idx = str(uuid.uuid4())
        SubTaskBase._subtasks_queus[self.idx] = self.q_in

    def wait(self, verbose=False) -> None:
        """Waits till the task is finished.

        :param verbose: if verbose, defaults to False
        :type verbose: bool, optional
        """
        time.sleep(0.025)
        progress = self.get_progress()
        pbar = tqdm(total=100) if verbose else None

        while progress < 1:
            time.sleep(0.05)
            progress = self.get_progress()
            if pbar:
                pbar.update(progress * 100 - pbar.n)

        if pbar:
            pbar.update(100 - pbar.n)

    def get_progress(self) -> float:
        """Returns progress of the running task.

        Base implementation

        :return: A progress (value between 0 and 1).
        :rtype: float
        """
        finished = not self.q_in.empty()

        if finished:
            return 1
        else:
            return 0

    def __init__(self) -> None:
        """Constructor."""
        self.process_id = os.getpid()
        self.q_in = queue.Queue()
        self.q_out = SubTaskBase._processes[self.process_id]["q_out"]
        self.idx = None

    def __del__(self):
        """Desctructor.

        Used to remove elements of _subtasks_queues
        """
        if self.idx is not None and self.idx in SubTaskBase._subtasks_queus:
            del SubTaskBase._subtasks_queus[self.idx]
            self.idx = None
