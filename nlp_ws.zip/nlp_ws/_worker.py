"""Worker implementation."""
from __future__ import absolute_import, division, unicode_literals

import json
import logging
import os
import time
from abc import ABCMeta, abstractmethod

import six

from ._subtask import SubTask

_log = logging.getLogger(__name__)


@six.add_metaclass(ABCMeta)
class NLPWorker(object):
    """The abstract class that all workers should be derived from.

    If defines methods which may be overridden to perform initialization of the
    worker, as well as the main processing method that will be called for every
    request to the worker.
    """

    MAX_PROGRESS = 0.99999999999
    PROGRESS_WAITING_TIME = 0.25

    @classmethod
    def static_init(cls, config):
        """Initialize shared resources.

        This initialization method is called exactly once, when the worker
        class is loaded and the service is starting.

        It should load and initialize resources that can be shared across
        processes, so that they don't need to be loaded many times.

        All variables added to this class by this method will be pickled and
        sent to all started processes. Therefore, they need to be picklable.

        :param config: The service configuration dictionary. It's passed
            whole to this method in case it wants to look at some of the
            parameters.
        :type config: dict
        """
        pass

    @classmethod
    def static_close(cls):
        """Called once after all workers shutdowns.

        Called after all processes have stopped and the service is shutting
        down. If any of shared resources allocated by :meth:`static_init` need
        to be cleaned up, the subclass should override this method to do so.
        """
        pass

    @staticmethod
    def logging_init(log_socket_handler, log_levels):
        """Called in each subprocess before :meth:`init`.

        The purpose of this method is to set up loggers used by the worker. By
        default, it takes all keys from ``logging_levels`` section of the
        configuration, treats them as logger names and sets their levels to the
        values assigned to them. All of those loggers also have
        ``log_socket_handler`` added as their handler, so they can log to the
        centralized logging system.

        This method silently does nothing when ``log_socket_handler`` is
        ``None``.

        Normally, there should be no reason to override this method in a
        subclass, unless some very special treatment of some loggers is
        required.

        :param log_socket_handler: The socket handler created for the process.
            This may be ``None`` if the central logger has not been set up.
        :type log_socket_handler: Optional[logging.handlers.SocketHandler]

        :param log_levels: Mapping of logger names to their levels. Normally
            taken from ``logging_levels`` section of config dictionary, after
            textual level names are resolved.
        :type log_levels: Mapping[str,int]
        """
        if log_socket_handler is None:
            return

        for name, level in six.iteritems(log_levels):
            logger = logging.getLogger(name)
            logger.setLevel(level)
            logger.addHandler(log_socket_handler)

    def init(self):
        """Initialize process.

        Called after an instance of this class has ben constructed in the
        process it will be run. It is run once for each instance
        (and therefore each process).

        It should load all resources that can't be pickled and shared.
        """
        pass

    def close(self):
        """Called when the process is being shut down.

        If the worker allocates any
        per-process resources that need to be cleaned up, the subclass should
        override this method to do so.
        """
        pass

    @abstractmethod
    def process(self, input_path, task_options, output_path):
        """Called for each request made to the worker.

        This method performs the
        task the service is constructed to do and must be overridden by
        subclasses.

        The process should read data from ``input_path``, process it according
        to ``task_options`` and static config (if any) and write it to
        ``output_path``.

        :param input_path: Path to either a file or directory from which
            the worker should read the data it needs.
        :type input_path: str

        :param task_options: Dictionary containing options for the current
            processing task. Subclasses should describe what options that can
            handle (or require). This dictionary may contain all values that
            can be JSON-encoded.
        :type task_options: dict

        :param output_path: Path to either a file or directory where the
            worker should store its output data.
        :type output_path: str
        :raises NotImplementedError: when method not implemented.
        """
        raise NotImplementedError(
            'File style of processing not yet implemented')

    def process_json(self, data, task_options):
        """Called for each request made to the worker.

        Called for each request made to the worker in case of JSON like style.
        This method performs the
        task the service is constructed to do and must be overridden by
        subclasses.

        The process should read data from ``data``, process it according
        to ``task_options`` and static config (if any) and write/change it to
        ``data``.

        :param data: Dictionary containing data for the current
            processing task. The worker should read the data it needs and add
            or modify it.
        :type data: dict

        :param task_options: Dictionary containing options for the current
            processing task. Subclasses should describe what options that can
            handle (or require). This dictionary may contain all values that
            can be JSON-encoded.
        :type task_options: dict
        :raises NotImplementedError: when method not implemented.
        """
        raise NotImplementedError(
            'JSON style of processing not yet implemented')

    def update_progress(self, progress):
        """Updates progress and check cancel.

        :param progress: the progress value to be set is less than
            or equal to one.
        :type progress: int
        :raises CanceledException: when task in canceled.
        """
        if self.cancel_event.is_set():
            raise CanceledException

        if (progress >= 1 or
            time.time() > self.last_time + self.PROGRESS_WAITING_TIME and
                progress > self.last_progress):
            self.last_progress = progress
            self.last_time = time.time()
            if progress >= 1:
                progress = self.MAX_PROGRESS
            self.q_progress.put(progress)

    def run(
            self,
            q_in,
            q_out,
            q_progress,
            cancel_event,
            q_subtask_in,
            q_subtask_out):
        """Main process function.

        Takes data from input queue and places it to the process method.
        Writes the results to the output queue.

        :param q_in: input queue.
        :type q_in: queue

        :param q_out: output queue.
        :type q_out: queue

        :param q_progress: progress queue.
        :type q_progress: queue

        :param cancel_event: cancel event.
        :type cancel_event: event

        :param q_subtask_in: queue to subtask.
        :type q_subtask_in: queue

        :param q_subtask_out: queue from subtask.
        :type q_subtask_out: queue
        """
        self.q_progress = q_progress
        self.cancel_event = cancel_event
        SubTask.prepare_subtask(
            {"q_in": q_subtask_in, "q_out": q_subtask_out}, os.getpid())
        while True:
            result = {'error': ''}
            data = q_in.get()
            start_time = time.time()
            self.last_progress = 0
            self.last_time = start_time
            opts = data['options']

            try:
                if 'data' in data:
                    data_json = json.loads(data['data'])
                    self.process_json(data_json, opts)
                    result['data'] = json.dumps(data_json)
                else:
                    in_file = data['file']
                    result['file'] = data['out_file']
                    result['response'] = self.process(
                        in_file, opts, data['out_file'])
            except CanceledException:
                _log.info("Task was internally canceled")
                result['error'] = "Canceled task"
                cancel_event.clear()

            except Exception as e:
                _log.exception('Unable to process the subtask with message: %s',
                               str(data))
                result['error'] = six.text_type(e)

            q_out.put(result)
            duration = time.time() - start_time
            _log.info('Finished internal processing of a subtask in %g',
                      duration)


class CanceledException(Exception):
    """Canceled exception."""

    pass
