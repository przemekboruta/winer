"""Sentence implementation."""
import logging

from ._subtaskbase import SubTaskBase, _timeout_manager

_log = logging.getLogger(__name__)


class WrongSentNameException(Exception):
    """Class for wrong sentence worker name exception.

    :param Exception: Exception
    :type Exception: class
    """

    pass


class Sentence(SubTaskBase):
    """Class implementing Sentence."""

    def __init__(self, sentences: list, sent_name: dict) -> None:
        """Constructor.

        :param sentences: list of sentences
        :type sentences: list
        :param sent_name: sentence worker name
        :type sent_name: dict
        :raises Exception: when Sentence is off
        :raises WrongSentNameException: when Sentence worker with given name
            does not exists in current system
        """
        if not Sentence._on:
            raise Exception(
                "Turn on Sentence features first, by Sentence.turn_on()\
                     in the top of the script (after import), run only once!!")
        if len(sentences) > 200:
            raise Exception("Max 200 of sentences allowed")
        super().__init__()
        self.sentences = sentences
        self.sent_name = sent_name
        if not self._sentence_exists():
            raise WrongSentNameException(
                f"Sentence worker '{sent_name}' \
                    does not exists in current system. Use other values.")
        self.results = [None for s in self.sentences]

    def _sentence_exists(self) -> bool:
        """Checks if queue 'sent_'sent_name exists in the system.

        :return: true if sentence queue exists, false otherwise
        :rtype: bool
        """
        self.get_new_idx()
        data = {
            "message": "sentence_exists",
            "pid": self.process_id,
            "sent_name": self.sent_name,
            "id": self.idx
        }
        self.q_out.put(data)

        response = self.q_in.get()
        return response["response"]

    def run(self, blocking=True, timeout=0, verbose=False) -> None:
        """Run task.

        :param blocking: If the call of this function should be blocking,
            defaults to True.
        :type blocking: bool, optional

        :param timeout: Timeout used if blocking=True.
            Pass '0' if the function should wait until the task is
            finished or error occurred (raise an exception), defaults to 0.
        :type timeout: float, optional

        :param verbose: Print progress or not, defaults to False.
        :type verbose: bool, optional
        """
        self.get_new_idx()

        self.results = [None for s in self.sentences]

        if self.sent_name == "dummy":
            self.results = [[0] for s in self.sentences]
            return

        ids = 0
        for text in self.sentences:
            data = {
                "message": "sentence",
                "pid": self.process_id,
                "sent_task": {"text": text},
                "sent_name": self.sent_name,
                "id": self.idx + "#" + str(ids)
            }

            ids += 1
            self.q_out.put(data)

        if blocking:
            with _timeout_manager(timeout, str(self.sent_name)):
                self.wait(verbose=verbose)

    def get_progress(self) -> float:
        """Returns progress of the running task.

        :return: A progress (value between 0 and 1).
        :rtype: float
        """
        while not self.q_in.empty():
            data = self.q_in.get()
            self.results[int(data["sub_id"])] = data["value"]

        finished = 0
        for update in self.results:
            if update is not None:
                finished += 1
        progress = min(finished / len(self.results), 1.0)

        return progress

    def get_results(self, timeout=0) -> list:
        """Returns list of results (result of completed task).

        The function waits if its needed.

        :param timeout: timeout, defaults to 0
        :type timeout: int, optional
        :return: task result
        :rtype: list
        """
        if self.get_progress() < 1:
            with _timeout_manager(timeout, str(self.sent_name)):
                self.wait()
        return self.results
