import json
import logging
import typing

from aio_pika import Connection, ExchangeType

_log = logging.getLogger(__name__)


class Handler(typing.NamedTuple):
    """Class for storing handlers.

    :param typing: named tuple
    :type typing: typing.NamedTuple
    """

    command: str
    function: typing.Callable


class Controller:
    """Class that handle callbacks for registered operations."""

    def __init__(self, tool_name: str, exchange_name="nlp_controller"):
        """Initializes controller.

        :param tool_name: name of tool
        :type tool_name: str

        :param exchange_name: exchange name. Defaults to "nlp_controller".
        :type exchange_name: str, optional
        """
        self.exchange_name = exchange_name
        self.tool_name = tool_name
        self.handlers = []

    def register_handler(self, handler: Handler):
        """Adds handler to handlers colletion.

        :param handler: handler to add
        :type handler: Handler
        """
        self.handlers.append(handler)

    async def serve(self, connection: Connection):
        """Handles callbacks.

        :param connection: connection
        :type connection: Connection
        """
        async with connection:
            channel = await connection.channel()
            await channel.set_qos(prefetch_count=1)

            controller_exchange = await channel.declare_exchange(
                self.exchange_name, ExchangeType.DIRECT,
            )
            queue = await channel.declare_queue(durable=False, auto_delete=True)
            await queue.bind(controller_exchange, routing_key=self.tool_name)

            _log.info('Starting controller  for {}'.format(self.tool_name))
            async with queue.iterator() as queue_iter:
                async for message in queue_iter:
                    async with message.process():

                        data = json.loads(message.body)
                        _log.debug('Controller received: {}'.format(data))
                        task = data["task"]
                        for handler in self.handlers:
                            if handler.command == task:
                                await handler.function(data)
