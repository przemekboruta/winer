"""NLPService implementation."""
from __future__ import (absolute_import, division, print_function,
                        unicode_literals)

import asyncio
import io
import json
import logging
import os
import re
import time
from logging.handlers import SocketHandler
from datetime import datetime

import setproctitle
import aioprocessing as ap
import six
from aio_pika import Message, connect_robust
from six.moves import configparser, input, xrange

from . import logserver
from ._controller import Controller, Handler
from ._subtask import SubTask
from ._worker import NLPWorker

_log = logging.getLogger(__name__)


CFG_SECTIONS = {
    'CFG_S_SERV': 'service',
    'CFG_S_TOOL': 'tool',
    'CFG_S_LOG': 'logging',
    'CFG_S_LOGLEVELS': 'logging_levels'
}


class NLPService(object):
    """Class implementing NLPService.

    Represents a web service using a :class:`NLPWorker` subclass connected to a
    RabbitMQ queue that receives tasks from the queue.

    TODO: This docstring should probably be extended with more description of
    the service system.

    Each service is constructed using a configuration dictionary in the
    following format::

        {
            "service": {
                    "root": "/samba/requests/",
                    "tool": "some-tool-name",
                    "rabbit_host": "0.0.0.0",
                    "rabbit_user": "admin",
                    "rabbit_password": "admin"
                },
            "tool": {
                "workers_number": 10
            },

            "logging": {
                "port": 4040
            }
        }

    The meaning of the options are as follows:

    * ``service/root``: The root directory where input and output directories
      for the service are.
    * ``service/tool``: The name of the created service (will be used to
      identify directories and queues).
    * ``service/rabbit_host``: IP address of the host where the RabbitMQ server
      is running.
    * ``service/rabbit_user`` and ``service/rabbit_password``: Credentials for
      interacting with the RabbitMQ server.
    * ``tool/workers_number``: Number of concurrent worker processes started
      by this service. If this value is absent, it will default to 1.
    * ``logging/port``: Number of port on which logging server will be
      listening. This port is passed to worker initialization so that it can
      set its logger to sent records to a central location.

    The ``logging`` section also accepts options with the same names and
    semantics as arguments to :func:`logserver.configure_loggers`, to which
    they're passed if present.

    A wholly optional ``logging_levels`` section can be present, mapping logger
    names to their desired levels (either numeric or textual). This is
    interpreted only if ``logging/port`` is present and valid.

    The config dictionary may contain other values as well. It will be passed
    whole to the worker class during initialization.
    """

    CFG_S_SERV = 'service'
    CFG_S_SERV_OPT_ROOT = 'root'
    CFG_S_SERV_OPT_TOOL = 'tool'
    CFG_S_SERV_OPT_QUEUE_PREFIX = 'queue_prefix'
    CFG_S_SERV_OPT_SENT_QUEUE_PREFIX = 'sent_prefix'
    CFG_S_SERV_OPT_RABBIT_HOST = 'rabbit_host'
    CFG_S_SERV_OPT_RABBIT_USER = 'rabbit_user'
    CFG_S_SERV_OPT_RABBIT_PASSWORD = 'rabbit_password'
    CFG_S_SERV_OPT_RABBIT_PORT = 'rabbit_port'
    CFG_S_SERV_OPT_IS_PRODUCTION = 'is_production'
    CFG_S_SERV_OPT_LPMN = 'lpmn'

    CFG_S_TOOL = 'tool'
    CFG_S_TOOL_OPT_WORKERS_NUMBER = 'workers_number'

    CFG_S_LOG = 'logging'
    CFG_S_LOG_OPT_PORT = 'port'
    CFG_S_LOG_OPT_LOGFILE_NAME = 'logfile_name'
    CFG_S_LOG_OPT_LOGFILE_MAXSIZE = 'logfile_maxsize'
    CFG_S_LOG_OPT_LOGFILE_MAXBACKUPS = 'logfile_maxbackups'
    CFG_S_LOG_OPT_LOG_FORMAT = 'log_format'
    CFG_S_LOG_OPT_LOCAL_LOG_LEVEL = 'local_log_level'

    CFG_S_LOGLEVELS = 'logging_levels'

    @classmethod
    def _from_ini(cls, worker_class, ini_file, configure_logger=True):
        """Creates an instance of NLPService from config.

        Create an instance of ``NLPService`` using an INI file for the
        configuration dictionary.

        :param worker_class: The class of the worker to be started, must
            be a subclass of :class:`NLPWorker`.
        :type worker_class: type

        :param ini_file: Input stream open to an INI file which will be
            read to create the config dictionary.
        :type ini_file: TextIO

        :param configure_logger: Should logger be configured,
            defaults to True.
        :type configure_logger: bool, optional

        :return: Constructed instance.
        :rtype: NLPService
        """
        cp = _EnvsConfigParser()
        cp.readfp(ini_file)
        confdict = {
            sec: {
                optname: optval
                for optname, optval in cp.items(sec)
            }
            for sec in cp.sections()
        }

        return cls(worker_class, confdict, configure_logger)

    @classmethod
    def main(cls, worker_class, ini_path='./config.ini', pause_at_exit=False):
        """Creates an instance of NLPService.

        Create an instance of ``NLPService`` and start it immediately (calling
        the :meth:`.serve` method).

        This is a convenience method for worker scripts, to use as "main" which
        starts the service in one line of code.

        :param worker_class: The class of the worker to be started, must
            be a subclass of :class:`NLPWorker`.
        :type worker_class: type

        :param ini_path: Path to an INI file which will be used as service
            configuration, defaults to './config.ini'.
        :type ini_path: str, optional

        :param pause_at_exit: If ``True``, then after :meth:`.serve`
            exits, the program will wait for newline on stdin. Useful for
            keeping wrapper programs alive, defaults to False.
        :type pause_at_exit: bool, optional
        """
        if os.path.exists(ini_path) and os.path.isfile(ini_path):
            with io.open(ini_path) as ini_ifs:
                srv = cls._from_ini(worker_class, ini_ifs)
        else:
            srv = cls._from_ini(worker_class, None)

        asyncio.run(srv.serve())

        if pause_at_exit:
            input('[Press Enter to exit] ')

    async def _process_progress(self, channel, q_progress, progressQueue,
                                correlation_id):
        """Processes progress events.

        Processes progress events (real numbers) from q_progress and sends them
        to Rabbit progressQueue. When `None` received breaks processing
        (finish of task)

        :param channel: channel
        :type channel: aio_pika.Channel
        :param q_progress: progress queue
        :type q_progress: aioprocessing.Queue
        :param progressQueue: queue name on rabbitmq
        :type progressQueue: str
        :param correlation_id: correlation id
        :type correlation_id: str
        """
        while True:
            progress = await q_progress.coro_get()
            if progress is None:
                break
            if progressQueue is None:
                continue
            response = dict()
            response["progress"] = progress
            r_message = Message(body=json.dumps(response).encode(
                "utf-8"), correlation_id=correlation_id)
            await channel.default_exchange.publish(
                r_message, routing_key=progressQueue, mandatory=True
            )

    async def _subtask_queue_to_rabbit(self, connection):
        """Communication from subtask to rabbit.

        Format of data::
                { "message":"start"
                  "task": dict #json task
                  "id": UUID
                  "input": str #/samba/...
                  "replay_queue": aioprocessing.AioQueue() #communication queue
                  "task_id": str
                   "user": str }

        :param connection: connection
        :type connection: aio_pika.Connection
        :raises Exception: when received message is not implemented
        """
        self._runing_subtasks = {}
        async with connection:
            channel = await connection.channel()
            while True:
                data = await self.q_from_subtask.coro_get()

                if "message" not in data:
                    data["message"] = "start"

                self._runing_subtasks[data["id"]] = {"pid": data["pid"]}

                if data["message"] == "sentence_exists":
                    await self._send_sentence_exists_message(data, channel)
                elif data["message"] == "sentence":
                    await self._send_sentence_task_message(data, channel)
                elif data["message"] == "start":
                    await self._send_start_message(data, channel)
                else:
                    raise Exception(
                        f"Unimplemented messsage {data['message']}")
        _log.info("finishing _subtask_queue_to_rabbit")

    async def _send_sentence_exists_message(self, data, channel):
        """Send sentence exist message.

        :param data: dictionary with data
        :type data: dict
        :param channel: channel
        :type channel: aio_pika.Channel
        """
        exists = False
        routing_key = self._sent_prefix + data['sent_name']
        try:
            await channel.declare_queue(name=routing_key,
                                        passive=True)
            exists = True
        except Exception as e:
            _log.info(e)
            await channel.reopen()
            exists = False
        replay_queue = self._processes[data["pid"]]["q_to_subtask"]
        o_data = {"id": data["id"], "response": exists}
        await replay_queue.coro_put(o_data)

    async def _send_sentence_task_message(self, data, channel):
        """Send sentence task message.

        :param data: dictionary with data
        :type data: dict
        :param channel: channel
        :type channel: aio_pika.Channel
        """
        body = data["sent_task"]
        r_message = Message(
            body=json.dumps(body).encode("utf-8"),
            correlation_id=data["id"],
            reply_to=self._subtask_result_queue)
        await channel.default_exchange.publish(
            r_message,
            routing_key=self._sent_prefix + data['sent_name'],
            mandatory=True)

    async def _send_start_message(self, data, channel):
        """Send start message.

        :param data: dictionary with data
        :type data: dict
        :param channel: channel
        :type channel: aio_pika.Channel
        """
        body = {
            "id": data["id"],
            "task": data["task"],
            "input": data["input"],
            "user": "subtask",
            "task_name": 'subtask_{}'.format(
                self._processes[data["pid"]]["current_task_id"])
        }
        r_message = Message(
            body=json.dumps(body).encode("utf-8"),
            correlation_id=data["id"],
            reply_to=self._subtask_result_queue)
        await channel.default_exchange.publish(
            r_message, routing_key=self._lpmn_q_name, mandatory=True
        )

    async def _subtask_queue_from_rabbit(self, connection):
        """Communication from rabbit to subtask and subprocess.

        :param connection: connection
        :type connection: aio_pika.Connection
        """
        async with connection:
            channel = await connection.channel()
            await channel.set_qos(prefetch_count=1)
            _time = str(datetime.now()).replace(" ", "_")
            _name = "_subtask_" + self._name + _time
            queue = await channel.declare_queue(
                _name, auto_delete=True, durable=False
            )
            self._subtask_result_queue = queue.name
            _log.debug(
                'Starting subtask process with queue: %s',
                self._subtask_result_queue)

            async with queue.iterator() as queue_iter:
                async for message in queue_iter:
                    async with message.process():
                        data = json.loads(message.body)
                        if type(data) is dict and "id" in data:
                            idx = data["id"]
                        else:
                            idx = message.correlation_id
                            data = {"value": data, "id": idx}
                        if idx in self._runing_subtasks:
                            pid = self._runing_subtasks[idx]["pid"]
                            replay_queue = self._processes[pid]["q_to_subtask"]
                            del self._runing_subtasks[idx]
                            await replay_queue.coro_put(data)
                        else:
                            _log.warning("Unknown id of task {}".format(data))

    async def _process_queue(self, connection, queue_name, q_in, q_out,
                             q_progress, canceled, loop, process_pid):
        """Processes events from Rabbit queues.

        :param connection: connection
        :type connection: aio_pika.Connection
        :param queue_name: queue name
        :type queue_name: str
        :param q_in: input queue.
        :type q_in: aioprocessing.Queue
        :param q_out: output queue.
        :type q_out: aioprocessing.Queue
        :param q_progress: process queue.
        :type q_progress: aioprocessing.Queue
        :param canceled: canceled queue.
        :type canceled: _Canceled
        :param loop: event loop
        :type loop: asyncio.AbstractEventLoop
        :param process_pid: process id
        :type process_pid: int
        """
        loop = asyncio.get_event_loop()
        async with connection:
            channel = await connection.channel()
            await channel.set_qos(prefetch_count=1)
            queue = await channel.declare_queue(queue_name, auto_delete=False)
            channel_progress = await connection.channel()
            _log.debug('Starting worker with queue: %s', queue_name)
            async with queue.iterator() as queue_iter:
                async for message in queue_iter:
                    async with message.process():
                        response = {}
                        start_time = time.time()
                        progressQueue = None

                        try:
                            if message.redelivered:
                                raise RedeliveredException

                            data = json.loads(message.body)

                            if "task_id" in data:
                                self._start_task(data, message,
                                                 canceled, process_pid)
                            else:
                                _log.info('Starting elementary btask %s',
                                          message.correlation_id)

                            if 'progressQueue' in data:
                                progressQueue = data['progressQueue']
                            loop.create_task(self._process_progress(
                                channel_progress, q_progress, progressQueue,
                                message.correlation_id))

                            if "out_file" not in data:
                                data["out_file"] = os.path.join(
                                    self._wrk_path, message.correlation_id)
                            await q_out.coro_put(data)
                            response = await q_in.coro_get()

                        except RedeliveredException:
                            response['error'] = "Redelivered task"
                            response["redelivered"] = True
                            _log.info("Got redelivey subtask %s",
                                      message.correlation_id)

                        except CanceledException:
                            response["error"] = "Canceled task"
                            _log.info("Got cancel subtask %s",
                                      message.correlation_id)

                        except Exception as e:
                            _log.exception('''Unable to process subtask %s
                                            with message: %s''',
                                           message.correlation_id,
                                           message.body.decode('utf8'))
                            response['error'] = six.text_type(e)

                        finally:
                            """ To stop progress corutine """
                            await q_progress.coro_put(None)
                            self._processes[process_pid]["current_task_id"] = \
                                None

                        duration = time.time() - start_time
                        response['time'] = duration
                        _log.info('Finished processing subtask %s in %g',
                                  message.correlation_id,
                                  duration)
                        reply_to = message.reply_to

                        r_message = Message(body=json.dumps(response).encode(
                            "utf-8"), correlation_id=message.correlation_id)
                        try:
                            await channel.default_exchange.publish(
                                r_message, routing_key=reply_to, mandatory=True
                            )
                        except Exception as e:
                            _log.exception('''Fatal error during publish
                                            with message: %s''',
                                           six.text_type(e))
                            os._exit(-1)

    def _start_task(self, data, message, canceled, process_pid):
        """Start elementary task with given options.

        :param data: dictionary with data
        :type data: dict
        :param message: message
        :type message: aio_pika.Message
        :param canceled: canceled queue.
        :type canceled: _Canceled
        :param process_pid: process id
        :type process_pid: int
        :raises CanceledException: when task with given id is canceled
        """
        _log.info(
            'Starting elementary task %s \
                with task_id %s and options %s',
            message.correlation_id,
            data["task_id"],
            str(data['options'])[:100])
        if canceled.is_canceled(data["task_id"]):
            raise CanceledException
        self._processes[process_pid]["current_task_id"] = data["task_id"]
        self._processes[process_pid]["cancel_event"].clear()

    # Process method is static to not copy the self reference.
    @staticmethod
    def _worker_process(worker_class,
                        worker_path,
                        log_address,
                        log_levels,
                        q_in,
                        q_out,
                        q_progress,
                        cancel_event,
                        q_to_subtask,
                        q_from_subtask
                        ):
        """Main worker processing.

        :param worker_class: The class of the worker to be started, must
            be a subclass of :class:`NLPWorker`
        :type worker_class: type

        :param worker_path: Worker path, joined root path and tool name.
        :type worker_path: str

        :param log_address: Log address.
        :type log_address: str

        :param log_levels: Mapping of logger names to their levels. Normally
            taken from ``logging_levels`` section of config dictionary, after
            textual level names are resolved.
        :type log_levels: Mapping[str,int]

        :param q_in: input queue.
        :type q_in: queue

        :param q_out: output queue.
        :type q_out: queue

        :param q_progress: progress queue.
        :type q_progress: queue

        :param cancel_event: cancel event.
        :type cancel_event: event

        :param q_to_subtask: queue to subtask.
        :type q_to_subtask: queue

        :param q_from_subtask: queue from subtask.
        :type q_from_subtask: queue
        """
        logh = (SocketHandler(*log_address)
                if log_address is not None
                else None)
        worker_class.logging_init(logh, log_levels)
        wrk = worker_class()

        _log.info('Initializing %r', wrk)
        wrk.init()

        wrk.run(q_out, q_in, q_progress, cancel_event, q_to_subtask,
                q_from_subtask)

        _log.info('Finalizing %r', wrk)
        wrk.close()

    def __init__(self, worker_class, config, configure_logger=True):
        """Initialize NLPService.

        :param worker_class: The class of the worker to be started, must
            be a subclass of :class:`NLPWorker`.
        :type worker_class: type

        :param config: Configuration dictionary. Must contain at least the
            values described in this class's documentation.
        :type config: dict

        :param configure_logger: Whether call the logger-configuring
            function. It can only be called once per main process, due to
            loggers' global nature. If this is ``False``, then all
            ``[logging]`` parameters aside from ``port`` will be ignored.
            However, it should not normally be necessary to ever create more
            than one instance of ``NLPService`` per main process, so passing
            anything beside the default value should never be needed. This
            parameter has no effect if there is no ``[logging]/port`` option in
            configuration, defaults to True.
        :type configure_logger: bool, optional
        :raises TypeError: when worker_class in not a NLPWorker
        """
        if not issubclass(worker_class, NLPWorker):
            raise TypeError('{!r} is not a NLPWorker'.format(worker_class))

        self._wrk_cls = worker_class
        self._cfg = config

        cfg_serv = config[self.CFG_S_SERV]

        self._sent_prefix = cfg_serv.get(self.CFG_S_SERV_OPT_SENT_QUEUE_PREFIX,
                                         'sent_')

        self._lpmn_q_name = (
            cfg_serv.get(self.CFG_S_SERV_OPT_QUEUE_PREFIX, 'nlp_') +
            cfg_serv.get(self.CFG_S_SERV_OPT_LPMN, 'lpmn'))

        self._name = cfg_serv[self.CFG_S_SERV_OPT_TOOL]
        self._q_name = (
            cfg_serv.get(self.CFG_S_SERV_OPT_QUEUE_PREFIX, 'nlp_') +
            cfg_serv[self.CFG_S_SERV_OPT_TOOL])
        self._wrk_path = os.path.join(cfg_serv[self.CFG_S_SERV_OPT_ROOT],
                                      cfg_serv[self.CFG_S_SERV_OPT_TOOL])
        self._r_host = cfg_serv[self.CFG_S_SERV_OPT_RABBIT_HOST]
        self._r_user = cfg_serv[self.CFG_S_SERV_OPT_RABBIT_USER]
        self._r_passwd = cfg_serv[self.CFG_S_SERV_OPT_RABBIT_PASSWORD]
        self._r_port = cfg_serv.get(self.CFG_S_SERV_OPT_RABBIT_PORT, 5672)

        self._is_production = cfg_serv.get(
            self.CFG_S_SERV_OPT_IS_PRODUCTION, "false"
        ).lower() == "true"

        if not os.path.exists(self._wrk_path):
            os.makedirs(self._wrk_path)

        try:
            cfg_log = config[self.CFG_S_LOG]
        except KeyError:
            self._log_srv = None
            self._log_lvls = {}
        else:
            self.__configure_logger(cfg_log, configure_logger)

            try:
                cfg_loglv = config[self.CFG_S_LOGLEVELS]
            except KeyError:
                self._log_lvls = {}
            else:
                self._log_lvls = {name: logserver.parse_loglevel(level)
                                  for name, level in six.iteritems(cfg_loglv)}

        try:
            cfg_tool = config[self.CFG_S_TOOL]
        except KeyError:
            self._wrk_num = 1
        else:
            self._wrk_num = int(cfg_tool.get(
                self.CFG_S_TOOL_OPT_WORKERS_NUMBER, 1))

    async def _connect(self, rabbit_host, rabbit_user, rabbit_passwd,
                       rabbit_port):
        """Connects to rabbit.

        :param rabbit_host: rabbit host
        :type rabbit_host: str
        :param rabbit_user: rabbit user
        :type rabbit_user: str
        :param rabbit_passwd: rabbit password
        :type rabbit_passwd: str
        :param rabbit_port: rabbit port
        :type rabbit_port: int
        :return: connection
        :rtype: aio_pika.Connection
        """
        connection = None
        while True:
            try:
                pars = "amqp://{}:{}@{}:{}/".format(
                    rabbit_user, rabbit_passwd, rabbit_host, rabbit_port)
                connection = await connect_robust(pars)
                break
            except ConnectionError:
                _log.info("Waiting for RabitMQ connection: " +
                          pars.replace(rabbit_passwd, "*******"))
                await asyncio.sleep(5)
        return connection

    async def serve(self):
        """Start receiving service requests and pass them to worker(s).

        This methods starts worker processes, request queues and a logging
        thread. It blocks until ``KeyboardInterrupt`` is sent, so it should
        be run from an interactive terminal.
        """
        loop = asyncio.get_event_loop()
        connection = await self._connect(self._r_host, self._r_user,
                                         self._r_passwd, self._r_port)
        _log.info('Initializing %r', self._wrk_cls)
        self._wrk_cls.static_init(self._cfg)

        if self._log_srv is not None:
            _log.info('Starting log server listening on %r',
                      self._log_srv.socket_address)
            self._log_srv.start()

        controller = Controller(self._name)
        canceled = _Canceled(expiry_in_hours=24)

        async def cancel_handler(data):
            canceled.add_task(data["id"])
            for process_dict in self._processes.values():
                if process_dict["current_task_id"] == data["id"]:
                    process_dict["cancel_event"].set()

        controller.register_handler(Handler("cancel", cancel_handler))
        loop.create_task(canceled.serve())
        loop.create_task(controller.serve(connection))
        self._processes = {}
        self.q_from_subtask = ap.AioQueue()

        if SubTask._on:
            loop.create_task(self._subtask_queue_from_rabbit(
                connection))
            loop.create_task(self._subtask_queue_to_rabbit(
                connection))

        for i in xrange(self._wrk_num):
            q_out = ap.AioQueue()
            q_in = ap.AioQueue()
            q_progress = ap.AioQueue()
            cancel_event = ap.AioEvent()
            cancel_event.clear()
            q_to_subtask = ap.AioQueue()
            p = ap.AioProcess(target=self._worker_process,
                              kwargs=dict(
                                  worker_class=self._wrk_cls,
                                  worker_path=self._wrk_path,
                                  log_address=self._log_srv.socket_address
                                  if self._log_srv is not None
                                  else None,
                                  log_levels=self._log_lvls,
                                  q_in=q_in,
                                  q_out=q_out,
                                  q_progress=q_progress,
                                  q_to_subtask=q_to_subtask,
                                  q_from_subtask=self.q_from_subtask,
                                  cancel_event=cancel_event
                              ),
                              name='worker-{}'.format(i),
                              )

            p.start()
            setproctitle.setproctitle(f'{i}-{self._name}')

            self._processes[p.pid] = {
                "process": p, "current_task_id": "None",
                "cancel_event": cancel_event, "q_to_subtask": q_to_subtask}
            loop.create_task(self._process_queue(
                connection, self._q_name, q_in, q_out, q_progress, canceled,
                loop, p.pid))

        print('=== Starting server, press Ctrl+C to quit ===')
        try:
            # Dummy join to hang till interrupt.
            # The interrupt is automatically propagated to all
            # subprocesses, so we just need to join on them again after
            # it has been sent.
            await p.coro_join()
        except KeyboardInterrupt:
            print('=== Quitting ===')
        _log.info('Finalizing %r', self._wrk_cls)
        self._wrk_cls.static_close()
        await connection.close()

        if self._log_srv is not None:
            _log.info('Log server on %r is going down',
                      self._log_srv.socket_address)
            self._log_srv.shutdown()
        exit(0)

    def __configure_logger(self, log_cfg, do_cfg):
        """Configures logger.

        :param log_cfg: logger configuration
        :type log_cfg: dict
        :param do_cfg: if logger should be configure
        :type do_cfg: bool
        """
        logport = log_cfg.get(self.CFG_S_LOG_OPT_PORT, 0)

        self._log_srv = logserver.LogServer(int(logport))

        if not do_cfg:
            return

        logconf_kwargs = {}

        if self.CFG_S_LOG_OPT_LOGFILE_MAXSIZE in log_cfg:
            logconf_kwargs[self.CFG_S_LOG_OPT_LOGFILE_MAXSIZE] = int(
                log_cfg[self.CFG_S_LOG_OPT_LOGFILE_MAXSIZE]
            )
        if self.CFG_S_LOG_OPT_LOGFILE_MAXBACKUPS in log_cfg:
            logconf_kwargs[self.CFG_S_LOG_OPT_LOGFILE_MAXBACKUPS] = int(
                log_cfg[self.CFG_S_LOG_OPT_LOGFILE_MAXBACKUPS]
            )
        if self.CFG_S_LOG_OPT_LOG_FORMAT in log_cfg:
            logconf_kwargs[self.CFG_S_LOG_OPT_LOG_FORMAT] = (
                log_cfg[self.CFG_S_LOG_OPT_LOG_FORMAT]
            )
        if self.CFG_S_LOG_OPT_LOCAL_LOG_LEVEL in log_cfg:
            logconf_kwargs[self.CFG_S_LOG_OPT_LOCAL_LOG_LEVEL] = (
                log_cfg[self.CFG_S_LOG_OPT_LOCAL_LOG_LEVEL]
            )

        if self.CFG_S_LOG_OPT_LOGFILE_NAME in log_cfg:
            logconf_kwargs[self.CFG_S_LOG_OPT_LOGFILE_NAME] = (
                log_cfg[self.CFG_S_LOG_OPT_LOGFILE_NAME]
            )

        logserver.configure_loggers(**logconf_kwargs)


class _EnvsConfigParser(configparser.RawConfigParser):
    """Reads an NLPService config from file.

    If parameter `filenames` is not None configuration is
    read from `filenames` with usage of RawConfigParser readfp method.

    Configuration options are overridden by enviromental variables that
    start with `CFG_S_`, and match pattern `section name`_OPT_`option name`.
    """

    def __init__(self):
        super().__init__()

    def readfp(self, filenames):
        if filenames:
            super().readfp(filenames)

        for name, value in os.environ.items():
            if re.search("^CFG_S_*", name):
                match = re.search(r"^(CFG_S_[A-Z]*)_OPT_(\w*)", name)
                if match and match.group(1) in CFG_SECTIONS:
                    sec = CFG_SECTIONS[match.group(1)]
                    option = match.group(2).lower()

                    if sec not in super().sections():
                        super().add_section(sec)
                    super().set(sec, option, value)


class CanceledException(Exception):
    """Canceled excpetion class.

    :param Exception: exception
    :type Exception: class
    """

    pass


class RedeliveredException(Exception):
    """Redelivered exception class.

    :param Exception: exception
    :type Exception: class
    """

    pass


class _Canceled:
    """Class for task canceling."""

    def __init__(self, expiry_in_hours):
        """Constructor.

        :param expiry_in_hours: time of expiry in hours
        :type expiry_in_hours: int
        """
        self.expiry_in_s = expiry_in_hours * 60 * 60
        self.tasks_canceled = dict()

    def add_task(self, task_id):
        """Adds tasks to canceled.

        :param task_id: task_id
        :type task_id: str
        """
        self.tasks_canceled[task_id] = time.time()

    def is_canceled(self, task_id):
        """If task in canceled.

        :param task_id: task id
        :type task_id: str
        :return: true if task was canceled false othetwise
        :rtype: bool
        """
        return task_id in self.tasks_canceled

    async def serve(self):
        """Serves."""
        while True:
            await asyncio.sleep(self.expiry_in_s / 4)

            now = time.time()
            for idx, started in self.tasks_canceled.values():
                if started + self.expiry_in_s > now:
                    del self.tasks_canceled[idx]
