# WiNER

WiNER is a tool for extracting identification units (mainly proper names) based on the Transformers architecture.