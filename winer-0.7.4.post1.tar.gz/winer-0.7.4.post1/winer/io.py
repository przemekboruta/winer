# -*- coding: utf-8 -*-
import clarin_json

from typing import Any, Dict, List, Optional, Tuple
from uuid import uuid4


class ClarinLexeme:
    
    def __init__(self, lemma: str, mstag: str, disamb: bool = False):
        self._lemma: str = lemma
        self._mstag: str = mstag
        self._disamb: bool = disamb

    def __str__(self):
        return f'{self._lemma}:{self._mstag}'
    
    def as_dict(self):
        return {'lemma': self._lemma, 'mstag': self._mstag, 'disamb': self._disamb}


class ClarinToken:
    
    def __init__(self, index: int, position: Tuple[int, int], orth: str, lexemes: Optional[List[ClarinLexeme]] = None):
        self._index: int = index
        self._position: Tuple[int, int] = position
        self._orth: str = orth
        self._lexemes: Optional[List[ClarinLexeme]] = lexemes

    def __str__(self) -> str:
        return self._orth

    def get_position(self) -> Tuple[int, int]:
        return self._position

    def get_lexemes(self) -> List[ClarinLexeme]:
        return self._lexemes if self._lexemes is not None else []

    def get_lexemes_as_dict(self) -> List[Dict[str, Any]]:
        return [lexem.as_dict() for lexem in self._lexemes] if self._lexemes is not None else []

    def as_dict(self):
        dict_repr = {'index': self._index, 'position': self._position, 'orth': self._orth}
        if self._lexemes is not None:
            dict_repr['lexemes'] = self.get_lexemes_as_dict()
        return dict_repr


class ClarinSpan:
    
    def __init__(self, orth: str, span_type: str, tokens: Tuple[int, int], position: Tuple[int, int]):
        self._orth: str = orth
        self._type: str = span_type
        self._tokens: Tuple[int, int] = tokens
        self._position: Tuple[int, int] = position
        self._id: int = uuid4().int

    def as_dict(self) -> Dict[str, Any]:
        return {'id': self._id, 'text': self._orth, 'type': self._type, 'tokens': self._tokens, 'positions': self._position}


def create_entities_from_hf_outputs(outputs) -> List[ClarinSpan]:
    return [ClarinSpan(ent['text'], ent['type'], (ent['tok_start'], ent['tok_end']), (ent['char_start'], ent['char_end'])) for ent in outputs]


class ClarinDocument:

    def __init__(self, filename: str, text: str, tokens: List[ClarinToken] = [], entities: List[ClarinSpan]= []):
        self._filename: str = filename
        self._text: str = text
        self._tokens: List[ClarinToken] = tokens
        self._entities: List[ClarinSpan] = entities

    def __str__(self):
        return self.get_text()

    def get_filename(self):
        return self._filename

    def get_text(self):
        return self._text

    def get_tokens(self) -> List[ClarinToken]:
        return self._tokens

    def get_entities(self) -> List[ClarinSpan]:
        return self._entities

    def get_pretokenized_text(self) -> List[str]:
        return [str(token) for token in self.get_tokens()]

    def add_entity(self, entity: ClarinSpan) -> None:
        self._entities.append(entity)

    def add_entities(self, entities: List[ClarinSpan]) -> None:
        self._entities.extend(entities)
    
    def as_dict(self) -> Dict[str, Any]:
        return {'filename': self.get_filename(), 'text': self.get_text(), 'tokens': self.get_tokens(), 'entities': self.get_entities()}

    def get_tokens_as_dict(self) -> List[Dict[str, Any]]:
        return [token.as_dict() for token in self.get_tokens()]

    def get_entities_as_dict(self) -> List[Dict[str, Any]]:
        return [entity.as_dict() for entity in self.get_entities()]

    def as_clarin_json(self) -> Dict[str, Any]:
        return {'filename': self.get_filename(), 'text': self.get_text(), 'tokens': self.get_tokens_as_dict(), 'entities': self.get_entities_as_dict()}


def create_document_from_clarin_json(clarin_json) -> ClarinDocument:
    def create_token_from_clarin_json(clarin_json_token) -> ClarinToken:
        def create_lexeme_from_clarin_json(clarin_json_lexeme) -> ClarinLexeme:
            return ClarinLexeme(lemma=clarin_json_lexeme['lemma'],
                                mstag=clarin_json_lexeme['mstag'],
                                disamb=clarin_json_lexeme['disamb'])
        return ClarinToken(index=clarin_json_token['index'],
                           position=tuple(int(indent) for indent in clarin_json_token['position']),
                           orth=clarin_json_token['orth'],
                           lexemes=[create_lexeme_from_clarin_json(lexeme) for lexeme in clarin_json_token['lexemes']] if 'lexemes' in clarin_json_token else None)
    return ClarinDocument(filename=clarin_json['filename'],
                          text=clarin_json['text'],
                          tokens=[create_token_from_clarin_json(token) for token in clarin_json['tokens']],
                          entities=[])


def read_clarin_json(path: str) -> Dict[str, Any]:
    with open(path, 'r', encoding='utf-8-sig') as fin:
        return json.load(fin)


def write_clarin_json(output_dictionary: Dict[str, Any], path: str) -> None:
    with open(path, 'w', encoding='utf-8') as fout:
        json.dump(output_dictionary, fout, ensure_ascii=False)

def extend_clarin_json(path: str, input_json: Dict[str, Any], entities: List[ClarinSpan]):
    input_json['entities'] = [entity.as_dict() for entity in entities]
    with open(path, 'w', encoding='utf-8') as fout:
        json.dump(input_json, fout, ensure_ascii=False)
