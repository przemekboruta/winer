# -*- coding: utf-8 -*-
import typer

from typing import Optional

app = typer.Typer()

@app.command()
def train(dataset_name: str, base_model_name: str, new_model_name: str, learning_rate: float = typer.Argument(6e-5), num_train_epochs: int = typer.Argument(25), batch_size: int = typer.Argument(16), weight_decay: float = typer.Argument(0.01), push_to_hub: bool = typer.Argument(True)):
    # Loading dataset.
    from datasets.load import load_dataset
    raw_dataset = load_dataset(dataset_name)
    ner_feature = raw_dataset['train'].features['ner']
    label_names = ner_feature.feature.names

    # Processing the data.
    from transformers import AutoTokenizer
    from winer import tokenize_and_align_labels_with_tokenizer
    tokenizer = AutoTokenizer.from_pretrained(base_model_name, add_prefix_space=True)
    tokenize_and_align_labels = tokenize_and_align_labels_with_tokenizer(tokenizer)
    tokenized_dataset = raw_dataset.map(tokenize_and_align_labels, batched=True, remove_columns=raw_dataset['train'].column_names)

    # Data collation
    from transformers import DataCollatorForTokenClassification
    data_collator = DataCollatorForTokenClassification(tokenizer=tokenizer)

    # Evaluation
    import evaluate
    from winer import compute_metrics_for_label_names_and_metric
    metric = evaluate.load('seqeval')
    compute_metrics = compute_metrics_for_label_names_and_metric(label_names, metric)
    
    # Defining the model
    id2label = {i: label for i, label in enumerate(label_names)}
    label2id = {v: k for k, v in id2label.items()}

    from transformers import AutoModelForTokenClassification
    model = AutoModelForTokenClassification.from_pretrained(base_model_name, id2label=id2label, label2id=label2id)

    from transformers import TrainingArguments
    args = TrainingArguments(
        new_model_name,
        evaluation_strategy='epoch',
        save_strategy='epoch',
        learning_rate=learning_rate,
        num_train_epochs=num_train_epochs,
        per_device_train_batch_size=batch_size,
        per_device_eval_batch_size=4*batch_size,
        weight_decay=weight_decay,
        load_best_model_at_end=True,
        hub_model_id=f'clarin-knext/{new_model_name}',
        hub_strategy='end',
        push_to_hub=push_to_hub,
        hub_private_repo=True
        )

    from transformers import Trainer
    trainer = Trainer(
        model=model,
        args=args,
        train_dataset=tokenized_dataset['train'],
        eval_dataset=tokenized_dataset['validation'],
        data_collator=data_collator,
        compute_metrics=compute_metrics,
        tokenizer=tokenizer)
    trainer.train()
    trainer.push_to_hub(commit_message='Training complete.')


@app.command()
def evaluate(dataset_name: str, model_name: str, device: str = typer.Argument('cpu')):
    # Prepare model
    from winer import Winer
    nlp = Winer(model_name, device=device)

    # Load dataset
    from datasets import load_dataset
    data = load_dataset(dataset_name, split="test")
    id2label = {i: label for i, label in enumerate(data.features['ner'].feature.names)}
    tokenized_inputs = data['tokens']
    gold_labels = [[id2label[label] for label in line] for line in data['ner']]

    # Tokenize input.
    encoded_inputs = nlp.tokenize(tokenized_inputs)
    
    # Predict with model.
    predictions_per_token = nlp.predict(encoded_inputs)

    # Aggregate results to words.
    from winer import allign_into_words
    aggregations = [allign_into_words(tokens, labels) for tokens, labels in zip([encoded_inputs.word_ids(index) for index in range(len(predictions_per_token))], predictions_per_token)]
        
    # Evaluation
    from seqeval.metrics import classification_report
    from seqeval.scheme import IOB2
    results = classification_report(gold_labels, aggregations, digits=5, mode='strict', scheme=IOB2)
    
    # Print metrics
    print('----- ----- ----- ----- -----')
    print(f'Dataset: {dataset_name}')
    print(f'Model: {model_name}')
    print('----- ----- -----')
    print(results)
    print('----- ----- ----- ----- -----')


@app.command()
def predict(model_name: str, data_path: str, batch_size: int = typer.Argument(256)):
    from winer import Winer
    nlp = Winer(model_name, batch_size=batch_size)

    import clarin_json
    from clarin_json.containers import Span
    from winer import get_sentences_from_document
    from winer import allign_into_entities
    with clarin_json.open(data_path.replace('.json', '.clarin.json'), "w", ensure_ascii=False) as fout:
        with clarin_json.open(data_path, "r") as fin:
            for document in fin:
                plain_inputs, tokenized_inputs, sent_starts = get_sentences_from_document(document)

                # Process data
                aggregations = nlp.process(tokenized_inputs)
                
                # Aggregate results to entities.
                entities = allign_into_entities(tokenized_inputs, aggregations, inputs_sentences=plain_inputs, sentences_range=sent_starts)
                document.set_spans([Span(**entity) for sent_entities in entities for entity in sent_entities], "ner")

                # Save document
                fout.write(document)            
    

if __name__ == '__main__':
    app()
