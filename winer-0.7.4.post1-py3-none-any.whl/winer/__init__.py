# -*- coding: utf-8 -*-

from typing import Optional
from uuid import uuid4

def align_labels_with_subwords(labels, word_ids):
    new_labels = []
    current_word = None
    for word_id in word_ids:
        if word_id != current_word:
            # Start of a new word!
            current_word = word_id
            label = -100 if word_id is None else labels[word_id]
            new_labels.append(label)
        elif word_id is None:
            # Special token
            new_labels.append(-100)
        else:
            # Same word as previous token
            label = labels[word_id]
            # If the label is B-XXX we change it to I-XXX
            # TODO: Need investigation.
            if label % 2 == 1:
                label += 1
            new_labels.append(label)
    return new_labels


def tokenize_and_align_labels_with_tokenizer(tokenizer):
    def tokenize_and_align_labels(examples):
        tokenized_inputs = tokenizer(examples['tokens'], truncation=True, is_split_into_words=True)
        all_labels = examples['ner']
        new_labels = []
        for i, labels in enumerate(all_labels):
            word_ids = tokenized_inputs.word_ids(i)
            new_labels.append(align_labels_with_subwords(labels, word_ids))
        
        tokenized_inputs['labels'] = new_labels
        return tokenized_inputs
    
    return tokenize_and_align_labels


def compute_metrics_for_label_names_and_metric(label_names, metric):
    import numpy as np
    
    def compute_metrics(eval_preds):
        logits, labels = eval_preds
        predictions = np.argmax(logits, axis=-1)
        
        # Remove ignored index (special tokens) and convert to labels
        true_labels = [[label_names[l] for l in label if l != -100] for label in labels]
        true_predictions = [
            [label_names[p] for (p, l) in zip(prediction, label) if l != -100]
            for prediction, label in zip(predictions, labels)
        ]
        all_metrics = metric.compute(predictions=true_predictions, references=true_labels, zero_division='0')
        return {
            "precision": all_metrics["overall_precision"],
            "recall": all_metrics["overall_recall"],
            "f1": all_metrics["overall_f1"]
        }
    
    return compute_metrics


from itertools import compress


def allign_into_words(encoded_inputs, labels, last_word_idx: int = 0):
        special_tokens_mapping = [x == 0 for x in encoded_inputs.special_tokens_mask]
        tokens = list(compress(encoded_inputs.word_ids, special_tokens_mapping))
        labels = list(compress(labels, special_tokens_mapping))
        word_labels = []
        for index in range(len(labels)):
            word_index = tokens[index]
            if last_word_idx == word_index:  # Mimic for FIRST aggregation strategy.
                word_labels.append(labels[index])
                last_word_idx += 1
        return word_labels, last_word_idx


def allign_into_entities(inputs, aggregations, inputs_sentences: Optional[str] = None, sentences_range: Optional[int] = None):
        entities = []
        for batch_nr, _ in enumerate(inputs):
            entities.append([])
            if inputs_sentences is None:
                inputs_sentences = [' '.join(doc) for doc in inputs]
            character_pointer = 0
            sent_offset = sentences_range[batch_nr] if sentences_range is not None else 0
            for label_nr, label in enumerate(aggregations[batch_nr]):
                if label != 'O':
                    label_prefix = label[:2]
                    label_type = label[2:]
                    text = inputs[batch_nr][label_nr]
                    begin = inputs_sentences[batch_nr].find(text, character_pointer)
                    character_pointer = begin + len(text)  # Character pointer will be also end of entity.
                    if label_prefix == 'B-':
                        entities[-1].append({'id': str(uuid4()), 'type': label_type, 'start': begin + sent_offset, 'stop': character_pointer + sent_offset})
                    elif label_prefix == 'I-':
                        if entities[-1] == [] or label_type != entities[-1][-1]['type']:
                            entities[-1].append({'id': str(uuid4()), 'type': label_type, 'start': begin + sent_offset, 'stop': character_pointer + sent_offset})
                        else:
                            entities[-1][-1]['stop'] = character_pointer + sent_offset
        return entities


import torch
from transformers import AutoModelForTokenClassification, AutoTokenizer

from datasets import Dataset
from torch.utils.data import DataLoader

from tqdm import tqdm


class Winer:

    def __init__(self, model_name, device: Optional[str] = None, batch_size: int = 256):
        self._device = device if device is not None else 'cuda' if torch.cuda.is_available() else 'cpu'
        self._tokenizer = AutoTokenizer.from_pretrained(model_name)
        self._tokenizer.model_max_length = 512
        self._model = AutoModelForTokenClassification.from_pretrained(model_name).to(self._device)
        self._batch_size = batch_size

    def tokenize(self, inputs):
        is_split_into_words = not isinstance(inputs[0], str)
        return self._tokenizer(inputs, return_tensors='pt', is_split_into_words=is_split_into_words, add_special_tokens=True, padding=True, truncation=True, return_overflowing_tokens=True, return_special_tokens_mask=True)

    def predict(self, batch):
        with torch.no_grad():
            outputs = self._model(batch['input_ids'].to(self._device), batch['attention_mask'].to(self._device))
            predictions = torch.argmax(outputs.logits, dim=2)
            return [[self._model.config.id2label[t.item()] for t in example] for example in predictions]
    
    def _allign_into_words(self, encoded_inputs, predictions_per_token, mapping_of_overflows):
        last_word_idx = 0
        last_sent_idx = 0
        words_labels = []
        for tokens, labels, sent_idx in zip([encoded_inputs[index] for index in range(len(predictions_per_token))], predictions_per_token, mapping_of_overflows):
            if last_sent_idx < sent_idx:
                last_word_idx = 0
                last_sent_idx = sent_idx
            batch_labels, last_word_idx = allign_into_words(tokens, labels, last_word_idx)
            words_labels.append(batch_labels)
        return words_labels

    def process(self, inputs):
        # Tokenize input.
        encoded_inputs = self.tokenize(inputs)
        mapping_of_overflows = encoded_inputs.pop('overflow_to_sample_mapping')
        
        # Transform data to data loader
        predict_dataset = Dataset.from_dict(encoded_inputs)
        predict_dataset = predict_dataset.with_format("torch")
        predict_dataloader = DataLoader(predict_dataset, batch_size=self._batch_size)
        
        # Predict with model.
        predictions_per_token = []
        for batch in tqdm(predict_dataloader):
            predictions_per_token.extend(self.predict(batch))

        # Aggregate results to words.
        word_allignments = self._allign_into_words(encoded_inputs, predictions_per_token, mapping_of_overflows)
        labels = [[] for _ in range(mapping_of_overflows[-1] + 1)]
        for allign, overflow_idx in zip(word_allignments, mapping_of_overflows):
            labels[overflow_idx].extend(allign)
        return labels

import clarin_json
def get_sentences_from_document(document: clarin_json.containers.Document):
    sentences = {"plain": [], "tokenized": [], "ranges": []}
    if "sentence" in document.get_span_types():
        for sentence in document.spans("sentence"):
            start, stop = sentence.start, sentence.stop
            sentences["plain"].append(document.text[start:stop])
            sentences["tokenized"].append([])
            sentences["ranges"].append(start)
            for token in document.tokens():
                if token.start < start:
                    continue
                elif token.start >= stop:
                    break
                else:
                    sentences["tokenized"][-1].append(document.get_orth(token))
    else:
        sentences["plain"] = [document.text]
        sentences["tokenized"] = [[document.get_orth(token) for token in document.tokens()]]
        sentences["ranges"] = [0]
    return sentences["plain"], sentences["tokenized"], sentences["ranges"]
